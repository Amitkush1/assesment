export enum FORM_TYPES {
    paragraph = 'paragraph',
    checkboxlist = 'checkboxlist'
}