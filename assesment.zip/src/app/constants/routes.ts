export class ROUTES  {
    static readonly EMPTY = '';
    static readonly WILD_CARD_ROUTE = '**';
    static readonly FORM = 'form';
    static readonly BUILDER = 'builder';
    static readonly ANSWER = 'answers';
}